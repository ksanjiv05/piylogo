export const static_URL = "http://localhost:4000/static/uploads/";
export const API_URL = "http://localhost:4000/api";
