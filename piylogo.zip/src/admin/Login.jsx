const Login = () => {
  return (
    <div class="w-full flex flex-col items-center justify-center">
      <div class="w-[100vw/2]">
        <br />
        <br />
        <br />
        <br />
        <input
          type="text"
          class="w-full border-2 p-2 border-black"
          placeholder="Username"
        />
        <br />
        <br />
        <input
          type="text"
          class="w-full border-2 p-2 border-black"
          placeholder="Password"
        />
        <br />
        <br />
        <button class="w-full border-2 border-black">Sign In</button>
      </div>
    </div>
  );
};

export default Login;
