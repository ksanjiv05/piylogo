const Header = () => {
  return (
    <header class="flex flex-row items-center justify-center h-[60px] ">
      <div class="basis-1/3 items-center justify-center ">
        <img
          //   class="mx-auto"
          src="src/assets/images/PIY.png"
          height={44}
          width={44}
        />
      </div>
      <div class="flex-1 basis-1/3  ">
        <ul class="list-none flex mx-auto">
          <li class="flex-1 text-center uppercase text-[16px]">works</li>
          <li class="flex-1 text-center uppercase text-[16px] ">services</li>
          <li class="flex-1 text-center uppercase text-[16px]">studio</li>
          <li class="flex-1 text-center uppercase text-[16px]">contact</li>
        </ul>
      </div>
      <div class="basis-1/3 justify-end items-center">
        <ul class="list-none flex  float-right">
          <li class="mx-1">
            <img
              class="mx-auto"
              src="src/assets/icons/Instagram.png"
              height={24}
              width={24}
            />
          </li>
          <li class="mx-1 ">
            <img
              class="mx-auto"
              src="src/assets/icons/Linkedin.png"
              height={24}
              width={24}
            />
          </li>
          <li class="mx-1">
            <img
              class="mx-auto"
              src="src/assets/icons/X.png"
              height={24}
              width={24}
            />
          </li>
          <li class="ml-1">
            <img
              class="float-right"
              src="src/assets/icons/Youtube.png"
              height={24}
              width={24}
            />
          </li>
        </ul>
      </div>
    </header>
  );
};

export default Header;
