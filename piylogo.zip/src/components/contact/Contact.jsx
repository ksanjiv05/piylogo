import { createSignal, createEffect } from "solid-js";
import axios from "axios";
import { static_URL, API_URL } from "../../config/config";

const Contact = ({ painting }) => {
  const [loader, setLoader] = createSignal(false);
  const [data, setData] = createSignal({
    name: "",
    email: "",
    purpose: "",
    message: "",
    phone: "",
    address: "",
    website: "",
  });
  const onChange = (ev) => {
    const { name, value } = ev.target;
    // Update other fields
    setData({
      ...data(),
      [name]: value,
    });
  };

  const handleSubmit = (ev) => {
    ev.preventDefault();
    console.log(data());
    setLoader(true);
    axios
      .post(`${API_URL}/contact`, data(), {
        // headers: {
        //   "Content-Type": "multipart/form-data",
        // },
      })
      .then((res) => {
        console.log(res.data);
        setLoader(false);
        alert("Your message has been sent");
      })
      .catch((err) => {
        console.log(err);
        alert("Unable to send message");
        setLoader(false);
      });
  };

  // createEffect(() => {
  //   console.log(painting());
  //   setData({
  //     ...data(),
  //     name: painting()?.name,
  //     message: `i want this art ${painting()?._id} ${painting()?.description}`,
  //   });
  // });
  createEffect(() => {
    if (painting) {
      setData((prevData) => ({
        ...prevData,
        name: painting().name,
        message: `I want this art ${painting()._id} ${painting().description}`,
      }));
    }
  });

  return (
    <div id="contact" class="w-full  p-[80px] bg-[#252525]">
      <center>
        <div className=" md:w-[55%]  md:p-12 p-8 ">
          <h1 className=" text-white md:text-5xl text-[48px] md:mb-[36px] mb-[10px] uppercase text-center">
            Contact
          </h1>

          <label className=" text-white float-left">Your Name*</label>
          <br />
          <input
            type="text"
            name="name"
            onChange={onChange}
            className="w-[100%] px-2 h-10 md:mb-6 mb-2"
            value={data()?.name}
          />

          <label className=" text-white float-left">Your Purpose*</label>
          <br />
          <br />
          <div className="flex h-8  items-center justify-between ">
            <div className="flex items-center justify-center">
              <input
                type="radio"
                name="purpose"
                //value="service"
                value="buy art"
                onChange={onChange}
                className="text-white w-6 h-8 "
              />
              <label className=" text-white font-lato  md:text-xl text-[12px] mx-2">
                Buy Art
              </label>
            </div>
            <div className="flex items-center justify-center">
              <input
                type="radio"
                name="purpose"
                //value="service"
                onChange={onChange}
                className="text-white font-lato w-6 h-8 "
                value={"custom art"}
              />
              <label className=" text-white font-lato  md:text-xl text-[12px] mx-2">
                Custom Art
              </label>
            </div>
            <div className="flex items-center justify-center">
              <input
                type="radio"
                name="purpose"
                //value="service"
                onChange={onChange}
                className="text-white font-lato w-6 h-8 "
                value={"inquire"}
              />
              <label className=" text-white float-left md:text-xl text-[12px]  mx-2">
                Inquire
              </label>
            </div>
          </div>
          <br />

          <label className="  text-white float-left">Your Phone Number*</label>
          <br />
          <input
            type="text"
            name="phone"
            onChange={onChange}
            className="w-[100%] px-2 h-10 md:mb-6 mb-2"
            //value={data?.phone}
          />
          {/* <br />
          <br /> */}
          <label className=" text-white float-left">Your Email*</label>
          <br />
          <input
            type="text"
            name="email"
            onChange={onChange}
            className="w-[100%] px-2 h-10 md:mb-6 mb-2"
            //value={data?.email}
          />

          <label className=" text-white float-left">Your Message*</label>
          <br />
          <textarea
            rows={3}
            name="message"
            onChange={onChange}
            value={data()?.message}
            className="p-2 w-[100%]"
          ></textarea>

          <br />
          <br />

          <label className=" text-white float-left">Your Address*</label>
          <br />
          <textarea
            rows={3}
            name="address"
            onChange={onChange}
            //value={data?.message}
            className="p-2 w-[100%]"
          ></textarea>

          <div
            onClick={handleSubmit}
            disabled={loader()}
            className="  mt-[36px] py-[16px] px-[32px] bg-white hover:bg-blue-500 rounded-full cursor-pointer "
          >
            <p className=" uppercase  text-[24px] font-bold ">
              {loader() ? "Sending..." : "Contact"}
            </p>
            {/* <Image src={dr} /> */}
          </div>
        </div>
      </center>
      <div class="w-full h-[2px] bg-[#434343]" />

      <div class="mt-[40px] flex flex-row">
        <div class="w-full flex flex-row ">
          <img
            width={40}
            class="mr-[16px]"
            // height={40}
            src="src/assets/icons/1.png"
          />
          <img
            width={40}
            class="mr-[16px]"
            // height={40}
            src="src/assets/icons/2.png"
          />
          <img
            width={40}
            class="mr-[16px]"
            // height={40}
            src="src/assets/icons/3.png"
          />
          <img
            width={40}
            class="mr-[16px]"
            // height={40}
            src="src/assets/icons/4.png"
          />
          <img
            width={40}
            class="mr-[16px]"
            // height={40}
            src="src/assets/icons/5.png"
          />
        </div>

        <div class="flex-1"></div>
        <div class="flex flex-row ">
          <div class="border-r-[1px] px-4 border-[#434343] ">
            <img src="src/assets/icons/mail.png" width={40} height={40} />
          </div>
          <div class="border-r-[1px] px-4 border-[#434343] ">
            <img src="src/assets/icons/phone.png" width={40} height={40} />
          </div>
          <div class=" w-[230px] pl-4">
            <h2 class=" text-[24px] text-white">Privacy Policy</h2>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
