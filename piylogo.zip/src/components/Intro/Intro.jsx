const Intro = () => {
  return (
    <div class="w-full flex flex-row  ">
      <div class="flex-1 base-1/3 float-left ">
        <img src="src/assets/images/Left.png" width={420} height={420} />
      </div>
      <div class="flex-1 base-1/3">
        <img
          class="mx-auto"
          src="src/assets/images/Center.png"
          width={420}
          height={420}
        />
      </div>
      <div class="flex-1 base-1/3 ">
        <img
          class=" float-right"
          src="src/assets/images/Right.png"
          width={420}
          height={420}
        />
      </div>
    </div>
  );
};

export default Intro;
