const Service = () => {
  return (
    <div class="w-full mt-[80px] p-[80px] bg-white">
      <h1 class=" uppercase text-[64px] text-center">Services</h1>

      <div class="grid grid-cols-2 gap-[30px]">
        <div class="rounded-[20px] my-[30px] overflow-hidden">
          <img class=" w-full h-[500px]  " src="public/assets/images/3.jpg" />
          <div class="w-full    p-[30px]  bg-[#333333]">
            <h2 class="text-[40px] text-white font-bold">Paintings</h2>
            <p class="text-[18px] py-[16px] text-white">
              "Bring your vision to life with bespoke artwork crafted to elevate
              your environment. Our painting services blend creativity with
              precision to create timeless pieces just for you."
            </p>
            <button class="bg-[#ffffff] mt-4 text-black text-[24px] px-[32px] py-[16px]  font-bold rounded-full ">
              Contact
            </button>
          </div>
        </div>
        <div class="rounded-[20px] my-[30px] overflow-hidden">
          <img class="w-full  h-[500px]   " src="public/assets/images/3.jpg" />
          <div class="w-full    p-[30px]  bg-[#333333]">
            <h2 class="text-[40px] text-white font-bold">Paintings</h2>
            <p class="text-[18px] py-[16px] text-white">
              "Bring your vision to life with bespoke artwork crafted to elevate
              your environment. Our painting services blend creativity with
              precision to create timeless pieces just for you."
            </p>
            <button class="bg-[#ffffff] mt-4 text-black text-[24px] px-[32px] py-[16px]  font-bold rounded-full ">
              Contact
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Service;
