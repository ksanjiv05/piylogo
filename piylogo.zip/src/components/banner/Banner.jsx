const Banner = () => {
  return (
    <div class="w-full h-[200px] bg-red-300 rounded-[20px] mt-[30px] ">
      <video
        // ref={videoRef}
        width="600"
        playsInline
        autoPlay
        // muted
        loop
        // controls
        // onEnded={() => setIsPlaying(false)}
      >
        <source src="public/assets/video/banner.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>
    </div>
  );
};

export default Banner;
