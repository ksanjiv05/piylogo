import Home from "./pages/Home";
import AppRoutes from "./routes/AppRoutes";

function App() {
  return <AppRoutes />; //<Home />;
}

export default App;
